from .getFnames import get_for_all_tabs
get_for_all_tabs()
from .collectFilesTab import collectFilesTab
from .diffParserTab import diffParserTab
from .directoryMapTab import directoryMapTab
from .extractImportsTab import extractImportsTab
from .finderTab import finderTab
from .functionsTab import functionsTab
from .runnerTab import runnerTab
