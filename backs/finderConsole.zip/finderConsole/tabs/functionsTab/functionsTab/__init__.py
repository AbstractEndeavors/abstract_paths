from .main import functionsTab
from abstract_gui.QT6.startConsole import  startConsole

def startFunctionsConsole():
    startConsole(functionsTab)
