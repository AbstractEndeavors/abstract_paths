from .main import *

def startContentFinderConsole():
    startConsole(ContentFinderConsole)

def startReactRunnerConsole():
    startConsole(reactRunnerConsole)
    
def startReactFinderShell():
    startConsole(reactFinderShell)
